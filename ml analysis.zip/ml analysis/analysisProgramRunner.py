import subprocess

# Call analysis.py
subprocess.run(["python", "analysis.py"])

# Call analysisWithRegion.py
subprocess.run(["python", "analysisWithRegion.py"])
